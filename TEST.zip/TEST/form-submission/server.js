const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

let users = [];
app.use(express.static('public'));
app.use(bodyParser.json());
app.post('/submit', (req, res) => {
    const { name, email } = req.body;

    if (name && email) {
        users.push({ name, email });
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }
});

app.listen(PORT, () => {
    console.log(`Running at http://localhost:${PORT}`);
});